# L5 L2 Classification — VPO2

**Model:** PAX L5 Narrow L2 General 27B
**Category:** CLOTHING_MANUFACTURING

This project is classified as a PAX L5 Narrow L2 integration target.
L5: production-ready deployment. L2: general-purpose domain application.

Upstream: https://github.com/valentina-project/vpo2
