# 25 Millennium Problem Proposals

**Project:** VPO2
**Upstream:** https://github.com/valentina-project/vpo2

Content specific to VPO2 in category CLOTHING_MANUFACTURING.
